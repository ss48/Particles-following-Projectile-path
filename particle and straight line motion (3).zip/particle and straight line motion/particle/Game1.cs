﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;

namespace particle
{
   /// <summary>
   /// This is the main type for your game.
   /// </summary>
   public class Game1 : Game
   {
      ParticleEngine particleEngine;
  
      GraphicsDeviceManager graphics;
      SpriteBatch spriteBatch;
      public float angle;
      private SpriteFont _debugFont;
      public Game1()
      {
       

         graphics = new GraphicsDeviceManager(this);
         Content.RootDirectory = "Content";
         graphics.PreferredBackBufferWidth = 1200;
         graphics.PreferredBackBufferHeight = 1200;
      }

      /// <summary>
      /// Allows the game to perform any initialization it needs to before starting to run.
      /// This is where it can query for any required services and load any non-graphic
      /// related content.  Calling base.Initialize will enumerate through any components
      /// and initialize them as well.
      /// </summary>
      protected override void Initialize()
      {
         // TODO: Add your initialization logic here
         
         base.Initialize();
      }

      /// <summary>
      /// LoadContent will be called once per game and is the place to load
      /// all of your content.
      /// </summary>
      protected override void LoadContent()
      {
         // Create a new SpriteBatch, which can be used to draw textures.
         spriteBatch = new SpriteBatch(GraphicsDevice);
         List<Texture2D> textures = new List<Texture2D>();
         textures.Add(Content.Load<Texture2D>("circle"));
         textures.Add(Content.Load<Texture2D>("circle2"));
         textures.Add(Content.Load<Texture2D>("star"));
         textures.Add(Content.Load<Texture2D>("diamond"));
         particleEngine = new ParticleEngine(textures, new Vector2(400, 240));


         _debugFont = Content.Load<SpriteFont>("NewSpriteFont");
       
         // TODO: use this.Content to load your game content here
      }

      /// <summary>
      /// UnloadContent will be called once per game and is the place to unload
      /// game-specific content.
      /// </summary>
      protected override void UnloadContent()
      {
         // TODO: Unload any non ContentManager content here
      }

      /// <summary>
      /// Allows the game to run logic such as updating the world,
      /// checking for collisions, gathering input, and playing audio.
      /// </summary>
      /// <param name="gameTime">Provides a snapshot of timing values.</param>
      protected override void Update(GameTime gameTime)
      {
         if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();
         if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Space))
         {
          //  particleEngine.EmitterLocation = new Vector2(Mouse.GetState().X, Mouse.GetState().Y);
            
        
          angle+=(float)Math.PI/100;
      //particleEngine.EmitterLocation = new Vector2(Mouse.GetState().X, Mouse.GetState().Y); //{Update EmitterLocation through mouse movements}
            //Projectile motion of particles
             particleEngine.EmitterLocation += new Vector2((float)(Math.PI/2)-(float)Math.Cos(angle),-1*(float)Math.Sin(angle));
             if (particleEngine.EmitterLocation.X >= GraphicsDevice.Viewport.Width)
             {
                particleEngine.EmitterLocation.X -= GraphicsDevice.Viewport.Width;
                particleEngine.EmitterLocation += new Vector2((float)(2*Math.PI ) + (float)Math.Cos(angle), -1 *(float)(2*Math.PI )* (float)Math.Sin(angle));
             }
         }
            particleEngine.Update();
         
            // TODO: Add your update logic here
         particleEngine.Positionp.X = MathHelper.Clamp(particleEngine.Positionp.X, 0, GraphicsDevice.Viewport.Width);
         particleEngine.Positionp.Y = MathHelper.Clamp(particleEngine.Positionp.Y, 0, GraphicsDevice.Viewport.Height);
            base.Update(gameTime);
           
      }
      private void WriteDebugInformation()
      {
         //   string positionInText = string.Format("Position of Jumper: ({0:0.0}, {1:0.0})", _jumper.Position.X, _jumper.Position.Y);
         //   string movementInText = string.Format("Current movement: ({0:0.0}, {1:0.0})", _jumper.Movement.X, _jumper.Movement.Y);
         string isOnFirmGroundText = string.Format("Press Space button for projectile motion", new Vector2(100, 400));
      }
      
     
      protected override void Draw(GameTime gameTime)
      {
         GraphicsDevice.Clear(Color.DarkBlue);
         WriteDebugInformation();
         // TODO: Add your drawing code here
         particleEngine.Draw(spriteBatch);
         base.Draw(gameTime);
      }
   }
}
